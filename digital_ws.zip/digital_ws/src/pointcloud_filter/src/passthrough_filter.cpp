#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/filters/passthrough.h>

ros::Publisher pub;

void cloud_cb(const sensor_msgs::PointCloud2ConstPtr& input)
{
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::fromROSMsg(*input, *cloud);

    // Passthrough filter on Z axis (depth)
    pcl::PassThrough<pcl::PointXYZ> pass;
    pass.setInputCloud(cloud);
    pass.setFilterFieldName("z");
    pass.setFilterLimits(0.5, 2.0);  // Filter range for depth
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered(new pcl::PointCloud<pcl::PointXYZ>);
    pass.filter(*cloud_filtered);

    // Additional passthrough filter on X axis (width)
    pass.setInputCloud(cloud_filtered);
    pass.setFilterFieldName("x");
    pass.setFilterLimits(-0.5, 0.5);  // Adjust this range to avoid the wall
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered_x(new pcl::PointCloud<pcl::PointXYZ>);
    pass.filter(*cloud_filtered_x);


    // Print the filtered points in a structured (x, y, z) format
    ROS_INFO("Filtered point cloud has %lu points", cloud_filtered_x->points.size());
    for (size_t i = 0; i < cloud_filtered_x->points.size(); ++i) {
        const pcl::PointXYZ& pt = cloud_filtered_x->points[i];
        ROS_INFO("Point %lu: [x: %f, y: %f, z: %f]", i, pt.x, pt.y, pt.z);
    }

    // Convert the filtered cloud back to a ROS message
    sensor_msgs::PointCloud2 output;
    pcl::toROSMsg(*cloud_filtered_x, output);
    output.header = input->header;

    pub.publish(output);
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "passthrough_filter_node");
    ros::NodeHandle nh;

    ros::Subscriber sub = nh.subscribe("/camera/depth_registered/points", 1, cloud_cb);
    pub = nh.advertise<sensor_msgs::PointCloud2>("/filtered_points", 1);

    ros::spin();
}
