import a.msg

import b.msg

import std_msgs.msg

s = std_msgs.msg.String()
a = a.msg.AMsg()
b = b.msg.BMsg()

print('<<< b >>>')
