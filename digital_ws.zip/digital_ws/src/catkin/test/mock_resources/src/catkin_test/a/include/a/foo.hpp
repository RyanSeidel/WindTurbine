#pragma once
namespace a {
  void foo();
}
