#include <iostream>

#include "root_pkg/root.hpp"

namespace root_pkg
{
void func()
{
  std::cout << "root_pkg::func()\n";
}
}
