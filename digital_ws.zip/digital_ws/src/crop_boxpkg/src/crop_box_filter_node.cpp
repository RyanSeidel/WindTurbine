#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_ros/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/filters/crop_box.h>
#include <pcl_conversions/pcl_conversions.h>

typedef pcl::PointCloud<pcl::PointXYZ> PointCloud;

class CropBoxFilterNode
{
public:
    CropBoxFilterNode()
    {
        // Subscribe to the input point cloud topic
        cloud_sub_ = nh_.subscribe("/camera/depth/points", 1, &CropBoxFilterNode::cloudCallback, this);
        
        // Publisher for the filtered point cloud
        cloud_pub_ = nh_.advertise<sensor_msgs::PointCloud2>("filtered_points", 1);
    }

    void cloudCallback(const sensor_msgs::PointCloud2ConstPtr& input)
    {
        // Convert sensor_msgs/PointCloud2 to PCL PointCloud
        PointCloud::Ptr cloud(new PointCloud);
        pcl::fromROSMsg(*input, *cloud);

        // Create Crop Box filter
        pcl::CropBox<pcl::PointXYZ> crop_box;
        crop_box.setMin(Eigen::Vector4f(-1.0, -1.0, 0.0, 1.0)); // Set min bounds
        crop_box.setMax(Eigen::Vector4f(1.0, 1.0, 2.0, 1.0));   // Set max bounds

        // Filter the point cloud
        PointCloud::Ptr cloud_filtered(new PointCloud);
        crop_box.setInputCloud(cloud);
        crop_box.filter(*cloud_filtered);

        // Convert the filtered point cloud to ROS message
        sensor_msgs::PointCloud2 output;
        pcl::toROSMsg(*cloud_filtered, output);

        // Set the frame ID and publish the filtered point cloud
        output.header.frame_id = input->header.frame_id;
        cloud_pub_.publish(output);
    }

private:
    ros::NodeHandle nh_;
    ros::Subscriber cloud_sub_;
    ros::Publisher cloud_pub_;
};

int main(int argc, char** argv)
{
    // Initialize the ROS node
    ros::init(argc, argv, "crop_box_filter_node");

    // Create the Crop Box filter node object
    CropBoxFilterNode cbfn;

    // Spin the node
    ros::spin();

    return 0;
}
