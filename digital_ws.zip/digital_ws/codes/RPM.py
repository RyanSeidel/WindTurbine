import paho.mqtt.client as mqtt
import time

# MQTT broker settings
mqtt_broker = "192.168.1.204"  # Raspberry Pi's IP address
mqtt_topic = "wind_turbine/hall_effect"

# Variables to track RPM
pulse_count = 0
last_detection_time = None

def calculate_rpm(pulse_count, time_interval):
    # RPM = (number of pulses / time in seconds) * 60
    if time_interval > 0:  # Ensure we're not dividing by zero or a very small time interval
        return (pulse_count / time_interval) * 60
    else:
        return 0

def on_message(client, userdata, msg):
    global pulse_count, last_detection_time

    if msg.payload.decode() == "Magnet detected!":
        current_time = time.time()

        if last_detection_time is None:  # First detection, set the last detection time
            last_detection_time = current_time
            return  # Skip calculation for the first detection

        # Calculate the time interval between this and the last detection
        time_interval = current_time - last_detection_time
        last_detection_time = current_time

        # Calculate RPM based on the time interval
        rpm = calculate_rpm(1, time_interval)  # 1 pulse for each detection
        print(f"RPM: {rpm:.2f}")

# MQTT setup and subscription
client = mqtt.Client()

def on_connect(client, userdata, flags, rc):
    print(f"Connected with result code {rc}")
    client.subscribe(mqtt_topic)

client.on_connect = on_connect
client.on_message = on_message

# Connect to MQTT broker and start listening for messages
client.connect(mqtt_broker, 1883, 60)
client.loop_forever()
